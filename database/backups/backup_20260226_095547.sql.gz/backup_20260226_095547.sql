/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.15-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ai_pondok_db
-- ------------------------------------------------------
-- Server version	10.11.15-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `absensis`
--

DROP TABLE IF EXISTS `absensis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `absensis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `santri_id` bigint(20) unsigned NOT NULL,
  `jenis` varchar(255) NOT NULL,
  `status` enum('hadir','sakit','izin','alfa') NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `absensis_santri_id_foreign` (`santri_id`),
  CONSTRAINT `absensis_santri_id_foreign` FOREIGN KEY (`santri_id`) REFERENCES `santris` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absensis`
--

LOCK TABLES `absensis` WRITE;
/*!40000 ALTER TABLE `absensis` DISABLE KEYS */;
/*!40000 ALTER TABLE `absensis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capaian_santris`
--

DROP TABLE IF EXISTS `capaian_santris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `capaian_santris` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `santri_id` bigint(20) unsigned NOT NULL,
  `materi_id` bigint(20) unsigned NOT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `nilai` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `capaian_santris_santri_id_foreign` (`santri_id`),
  KEY `capaian_santris_materi_id_foreign` (`materi_id`),
  CONSTRAINT `capaian_santris_materi_id_foreign` FOREIGN KEY (`materi_id`) REFERENCES `materis` (`id`) ON DELETE CASCADE,
  CONSTRAINT `capaian_santris_santri_id_foreign` FOREIGN KEY (`santri_id`) REFERENCES `santris` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capaian_santris`
--

LOCK TABLES `capaian_santris` WRITE;
/*!40000 ALTER TABLE `capaian_santris` DISABLE KEYS */;
INSERT INTO `capaian_santris` VALUES
(1,1,4,'2026-02-26',80,'2026-02-26 07:38:29','2026-02-26 07:38:29'),
(2,1,5,'2026-02-26',85,'2026-02-26 07:38:42','2026-02-26 07:38:42');
/*!40000 ALTER TABLE `capaian_santris` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jenis_absensis`
--

DROP TABLE IF EXISTS `jenis_absensis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jenis_absensis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jenis_absensis`
--

LOCK TABLES `jenis_absensis` WRITE;
/*!40000 ALTER TABLE `jenis_absensis` DISABLE KEYS */;
INSERT INTO `jenis_absensis` VALUES
(1,'Sholat Subuh',NULL,'2026-02-25 23:57:04','2026-02-25 23:57:04'),
(2,'Sholat Dhuhur',NULL,'2026-02-25 23:57:15','2026-02-25 23:57:15'),
(3,'Sholat Ashar',NULL,'2026-02-25 23:59:18','2026-02-25 23:59:18'),
(4,'Sholat Maghrib',NULL,'2026-02-25 23:59:26','2026-02-25 23:59:26'),
(5,'Sholat Isya',NULL,'2026-02-25 23:59:32','2026-02-25 23:59:32'),
(6,'Sholat Dhuha',NULL,'2026-02-25 23:59:39','2026-02-25 23:59:39'),
(7,'Sholat Tahajud',NULL,'2026-02-25 23:59:47','2026-02-25 23:59:47'),
(8,'Holaqoh Qur\'an',NULL,'2026-02-26 00:26:53','2026-02-26 00:26:53'),
(9,'Kajian Subuh',NULL,'2026-02-26 00:27:07','2026-02-26 00:27:07');
/*!40000 ALTER TABLE `jenis_absensis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jenis_pembayarans`
--

DROP TABLE IF EXISTS `jenis_pembayarans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jenis_pembayarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `kode` varchar(255) NOT NULL,
  `sifat` enum('bulanan','sekali','cicilan') NOT NULL DEFAULT 'sekali',
  `nominal_default` bigint(20) unsigned DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jenis_pembayarans_kode_unique` (`kode`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jenis_pembayarans`
--

LOCK TABLES `jenis_pembayarans` WRITE;
/*!40000 ALTER TABLE `jenis_pembayarans` DISABLE KEYS */;
INSERT INTO `jenis_pembayarans` VALUES
(1,'Pendaftaran','daftar','sekali',250000,NULL,'2026-02-25 22:29:03','2026-02-25 22:29:03'),
(2,'Wakaf Bangunan & Fasilitas','wakaf','cicilan',8500000,NULL,'2026-02-25 22:29:36','2026-02-25 22:29:36'),
(3,'SPP','spp','bulanan',2000000,NULL,'2026-02-25 22:29:54','2026-02-25 22:29:54');
/*!40000 ALTER TABLE `jenis_pembayarans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kamars`
--

DROP TABLE IF EXISTS `kamars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kamars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kamars_nama_unique` (`nama`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kamars`
--

LOCK TABLES `kamars` WRITE;
/*!40000 ALTER TABLE `kamars` DISABLE KEYS */;
INSERT INTO `kamars` VALUES
(1,'Mekah',NULL,'2026-02-25 22:20:20','2026-02-25 22:20:20');
/*!40000 ALTER TABLE `kamars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kelas`
--

DROP TABLE IF EXISTS `kelas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kelas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kelas_nama_unique` (`nama`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kelas`
--

LOCK TABLES `kelas` WRITE;
/*!40000 ALTER TABLE `kelas` DISABLE KEYS */;
INSERT INTO `kelas` VALUES
(1,'Programmer A',NULL,'2026-02-25 22:19:54','2026-02-25 22:19:54'),
(2,'Bisnis Digital A',NULL,'2026-02-25 22:20:12','2026-02-25 22:20:12'),
(3,'BISNIS DIGITAL',NULL,'2026-02-25 23:43:31','2026-02-25 23:43:31'),
(4,'PROGRAMMER',NULL,'2026-02-25 23:43:38','2026-02-25 23:43:38');
/*!40000 ALTER TABLE `kelas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materis`
--

DROP TABLE IF EXISTS `materis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `materis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materis`
--

LOCK TABLES `materis` WRITE;
/*!40000 ALTER TABLE `materis` DISABLE KEYS */;
INSERT INTO `materis` VALUES
(1,'Laravel - BackEnd','IT','laravel','2026-02-26 07:34:54','2026-02-26 07:34:54'),
(2,'React JS - FrontEnd','IT','reactjs','2026-02-26 07:35:14','2026-02-26 07:35:14'),
(3,'React Native - Mobile','IT','reactnative','2026-02-26 07:35:33','2026-02-26 07:35:33'),
(4,'Content Creator - Video','IT','contentvideo','2026-02-26 07:36:07','2026-02-26 07:36:07'),
(5,'Content Creator - Design','IT','design','2026-02-26 07:36:24','2026-02-26 07:36:24'),
(6,'Medsos Specialist','IT','medsos','2026-02-26 07:36:42','2026-02-26 07:36:42'),
(7,'Customer Service','IT','customer','2026-02-26 07:36:58','2026-02-26 07:36:58'),
(8,'Meta Ads','IT','meta','2026-02-26 07:37:14','2026-02-26 07:37:14'),
(9,'TikTok Affiliate','IT','tiktokaff','2026-02-26 07:37:32','2026-02-26 07:37:32');
/*!40000 ALTER TABLE `materis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_02_25_121241_create_wali_santris_table',1),
(5,'2026_02_25_121241_z_create_santris_table',1),
(6,'2026_02_25_121242_create_psb_registrations_table',1),
(7,'2026_02_25_121242_create_tagihan_spps_table',1),
(8,'2026_02_25_121242_z_create_pembayarans_table',1),
(9,'2026_02_25_121243_create_absensis_table',1),
(10,'2026_02_25_121243_create_pelanggarans_table',1),
(11,'2026_02_25_132912_create_jenis_absensis_table',1),
(12,'2026_02_25_132941_modify_jenis_in_absensis_table',1),
(13,'2026_02_25_135130_create_kamars_table',1),
(14,'2026_02_25_135130_create_kelas_table',1),
(15,'2026_02_25_173954_add_enriched_fields_to_santris_table',1),
(16,'2026_02_25_180646_create_materis_table',1),
(17,'2026_02_25_180647_create_capaian_santris_table',1),
(18,'2026_02_25_180647_create_portofolios_table',1),
(19,'2026_02_25_200951_create_jenis_pembayarans_table',1),
(20,'2026_02_25_200951_z_add_jenis_pembayaran_to_tagihan_spps',1),
(21,'2026_02_25_230656_make_wali_id_nullable_on_santris_table',2),
(22,'2026_02_25_231918_add_entitas_and_angkatan_to_santris_table',3),
(23,'2026_02_26_003712_change_status_column_on_santris_table',4),
(24,'2026_02_26_074946_create_permission_tables',5),
(25,'2026_02_26_090348_add_indexes_to_santris_table',6);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',1),
(1,'App\\Models\\User',2),
(2,'App\\Models\\User',3);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelanggarans`
--

DROP TABLE IF EXISTS `pelanggarans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelanggarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `santri_id` bigint(20) unsigned NOT NULL,
  `judul_pelanggaran` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `poin` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pelanggarans_santri_id_foreign` (`santri_id`),
  CONSTRAINT `pelanggarans_santri_id_foreign` FOREIGN KEY (`santri_id`) REFERENCES `santris` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelanggarans`
--

LOCK TABLES `pelanggarans` WRITE;
/*!40000 ALTER TABLE `pelanggarans` DISABLE KEYS */;
/*!40000 ALTER TABLE `pelanggarans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pembayarans`
--

DROP TABLE IF EXISTS `pembayarans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pembayarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tagihan_id` bigint(20) unsigned NOT NULL,
  `tanggal_bayar` date NOT NULL,
  `jumlah_bayar` decimal(15,2) NOT NULL,
  `metode_pembayaran` varchar(255) NOT NULL,
  `bukti_pembayaran` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pembayarans_tagihan_id_foreign` (`tagihan_id`),
  CONSTRAINT `pembayarans_tagihan_id_foreign` FOREIGN KEY (`tagihan_id`) REFERENCES `tagihan_spps` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembayarans`
--

LOCK TABLES `pembayarans` WRITE;
/*!40000 ALTER TABLE `pembayarans` DISABLE KEYS */;
INSERT INTO `pembayarans` VALUES
(1,3,'2026-02-17',2000000.00,'Transfer Bank',NULL,'2026-02-26 01:48:27','2026-02-26 01:48:27'),
(2,16,'2026-02-16',2000000.00,'Transfer Bank',NULL,'2026-02-26 01:49:45','2026-02-26 01:49:45'),
(3,7,'2026-02-12',2000000.00,'Transfer Bank',NULL,'2026-02-26 01:50:22','2026-02-26 01:50:22'),
(4,8,'2026-02-11',2000000.00,'Transfer Bank',NULL,'2026-02-26 01:53:21','2026-02-26 01:53:21'),
(5,4,'2026-02-11',2000000.00,'Transfer Bank',NULL,'2026-02-26 01:53:52','2026-02-26 01:53:52'),
(6,19,'2026-02-26',500000.00,'Transfer Bank',NULL,'2026-02-26 07:15:53','2026-02-26 07:15:53'),
(7,20,'2026-02-26',2000000.00,'Transfer Bank',NULL,'2026-02-26 07:17:38','2026-02-26 07:17:38'),
(8,21,'2026-02-26',2000000.00,'Transfer Bank',NULL,'2026-02-26 07:19:53','2026-02-26 07:19:53'),
(9,22,'2026-02-26',2000000.00,'Transfer Bank',NULL,'2026-02-26 07:20:33','2026-02-26 07:20:33'),
(10,23,'2026-02-26',2000000.00,'Transfer Bank',NULL,'2026-02-26 07:21:59','2026-02-26 07:21:59'),
(11,24,'2026-02-26',2000000.00,'Transfer Bank',NULL,'2026-02-26 07:22:30','2026-02-26 07:22:30'),
(12,25,'2026-02-15',1000000.00,'Transfer Bank',NULL,'2026-02-26 07:25:20','2026-02-26 07:25:20'),
(13,26,'2026-02-26',2000000.00,'Transfer Bank',NULL,'2026-02-26 07:29:22','2026-02-26 07:29:22');
/*!40000 ALTER TABLE `pembayarans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,'view santri','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(2,'create santri','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(3,'update santri','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(4,'delete santri','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(5,'view finance','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(6,'create finance','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(7,'update finance','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(8,'delete finance','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(9,'view psb','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(10,'create psb','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(11,'update psb','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(12,'delete psb','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(13,'view materi','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(14,'create materi','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(15,'update materi','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(16,'delete materi','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(17,'view attendance','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(18,'create attendance','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(19,'update attendance','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(20,'delete attendance','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(21,'view discipline','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(22,'create discipline','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(23,'update discipline','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(24,'delete discipline','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(25,'view users','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(26,'create users','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(27,'update users','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(28,'delete users','web','2026-02-26 08:02:48','2026-02-26 08:02:48');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portofolios`
--

DROP TABLE IF EXISTS `portofolios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `portofolios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `santri_id` bigint(20) unsigned NOT NULL,
  `judul` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `portofolios_santri_id_foreign` (`santri_id`),
  CONSTRAINT `portofolios_santri_id_foreign` FOREIGN KEY (`santri_id`) REFERENCES `santris` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portofolios`
--

LOCK TABLES `portofolios` WRITE;
/*!40000 ALTER TABLE `portofolios` DISABLE KEYS */;
INSERT INTO `portofolios` VALUES
(1,1,'Tim Media Pondok IT',NULL,NULL,'2024-01-26','2026-02-26 07:39:30','2026-02-26 07:39:30'),
(2,1,'Tim Media Pondok Entrepreneur',NULL,NULL,'2025-01-01','2026-02-26 07:40:24','2026-02-26 07:40:24'),
(3,1,'Tim Media Rumah IT',NULL,NULL,'2026-01-01','2026-02-26 07:41:12','2026-02-26 07:41:12');
/*!40000 ALTER TABLE `portofolios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psb_registrations`
--

DROP TABLE IF EXISTS `psb_registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `psb_registrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama_calon` varchar(255) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `nama_wali` varchar(255) NOT NULL,
  `no_hp_wali` varchar(255) NOT NULL,
  `berkas_kk` varchar(255) DEFAULT NULL,
  `berkas_akta` varchar(255) DEFAULT NULL,
  `berkas_ijazah` varchar(255) DEFAULT NULL,
  `status_seleksi` enum('pending','diterima','cadangan','ditolak') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psb_registrations`
--

LOCK TABLES `psb_registrations` WRITE;
/*!40000 ALTER TABLE `psb_registrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `psb_registrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES
(1,1),
(1,2),
(2,1),
(2,2),
(3,1),
(3,2),
(4,1),
(4,2),
(5,1),
(6,1),
(7,1),
(8,1),
(9,1),
(9,2),
(10,1),
(10,2),
(11,1),
(11,2),
(12,1),
(12,2),
(13,1),
(13,2),
(14,1),
(14,2),
(15,1),
(15,2),
(16,1),
(16,2),
(17,1),
(17,2),
(18,1),
(18,2),
(19,1),
(19,2),
(20,1),
(20,2),
(21,1),
(21,2),
(22,1),
(22,2),
(23,1),
(23,2),
(24,1),
(24,2),
(25,1),
(26,1),
(27,1),
(28,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Super Admin','web','2026-02-26 08:02:48','2026-02-26 08:02:48'),
(2,'Pengurus','web','2026-02-26 08:02:48','2026-02-26 08:02:48');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `santris`
--

DROP TABLE IF EXISTS `santris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `santris` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nis` varchar(255) DEFAULT NULL,
  `nama` varchar(255) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `tempat_lahir` varchar(255) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `minat_bakat` varchar(255) DEFAULT NULL,
  `cita_cita` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `no_hp` varchar(255) DEFAULT NULL,
  `wali_id` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(255) DEFAULT 'Santri Aktif',
  `entitas` varchar(255) DEFAULT NULL,
  `angkatan` int(11) DEFAULT NULL,
  `kamar` varchar(255) DEFAULT NULL,
  `kelas` varchar(255) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `santris_nis_unique` (`nis`),
  KEY `santris_wali_id_foreign` (`wali_id`),
  KEY `santris_nama_index` (`nama`),
  KEY `santris_nis_index` (`nis`),
  KEY `santris_status_index` (`status`),
  KEY `santris_kelas_index` (`kelas`),
  KEY `santris_kamar_index` (`kamar`),
  KEY `santris_entitas_index` (`entitas`),
  KEY `santris_angkatan_index` (`angkatan`),
  CONSTRAINT `santris_wali_id_foreign` FOREIGN KEY (`wali_id`) REFERENCES `wali_santris` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `santris`
--

LOCK TABLES `santris` WRITE;
/*!40000 ALTER TABLE `santris` DISABLE KEYS */;
INSERT INTO `santris` VALUES
(1,'016001','MUHAMMAD RIZKI','L',NULL,NULL,NULL,'Santri Alumni Pondok IT yang telah mengabdikan diri di bagian media pondok sebagai Content Creator',NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',16,NULL,'BISNIS DIGITAL','santri/S3aPxCp9phCx5fIw3OnP6VS5MmyO0DI9G1iFFJGk.png','2026-02-25 23:35:48','2026-02-26 09:17:09'),
(2,'017001','IRFAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',17,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(3,'017002','NAUFAL FAJAR','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',17,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 08:59:31'),
(4,'018001','HAMMAM','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',18,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(5,'018002','NAUFAL','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',18,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 08:59:31'),
(6,'019001','AZZAM','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',19,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(7,'019002','DZIKRI RABBANI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',19,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(8,'019003','IHSAN DAUD RAMADHAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',19,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(9,'019004','KHODHIR','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Keluar','PIT',19,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 02:53:04'),
(10,'019005','TAQY HUTAQI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Magang','PIT',19,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 02:53:51'),
(11,'020001','AMELIA PUTRI','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(12,'020002','ASMA\' AL HIKMAH','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(13,'020003','AYU FATMAWATI','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(14,'020004','BAGUS EKAPUTRA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(15,'020005','FAIZATUL \'ALIYAH','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(16,'020006','KHALISHA KAYLA KIFLI','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(17,'020007','MASURA DANI QUTHNI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(18,'020008','MAULIA PUTRI ANDINI','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(19,'020009','MUHAMMAD LUTHFI EFFENDI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(20,'020010','NASYA AUREL JACINDA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(21,'020011','RIDA NURIYAH','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(22,'020012','SHOFIA RATRI ADIBA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(23,'020013','SITI FATIMAH ZAHARA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(24,'020014','TASYA MANUSAMAL','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(25,'020015','YULIAWATI','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',20,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(26,'021001','FINA MUTHI\'AH','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(27,'021002','FIRMAN FELANI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(28,'021003','IKLIMA DHIYA AULIA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(29,'021004','IZZA AZZAM ASSYAAMEIL','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(30,'021005','LUKMAN SYARIF RAHMATULLAH','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(31,'021006','LUQMANUL HAKIEM','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(32,'021007','MUHAMMAD AL FATIH MUZAKKI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(33,'021008','MUHAMMAD FIKRI BAIHAQI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(34,'021009','MUHAMMAD HUBAIB','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(35,'021010','NIDA IZZATI SALSABILA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(36,'021011','RAKA BAGUS PRATAMA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(37,'021012','RANGGA WIJAYA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(38,'021013','RIZKI PUTRA DANDI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(39,'021014','SULTAN GUFAEDI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(40,'021015','WAHYU RAMADANI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',21,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(41,'022001','ERLINA FEBRILIAN IVANA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(42,'022002','FAUZAN IBNU SABILL','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(43,'022003','FAUZI IBNU SABILL','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(44,'022004','HABIL RASYID','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(45,'022005','M HARITS','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(46,'022006','MUHAMMAD FARIS SYUHADA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(47,'022007','MUHAMMAD RIZQI SETIAWAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(48,'022008','MUHAMMAD THORIQ','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(49,'022009','NADYA SISKA DEWI','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(50,'022010','NAUFAL HIBATULLAH NURIL AZMI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(51,'022011','NAUFALINO RADHISYA WIBAWA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(52,'022012','PANDU MUHAMAD WIBAWA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(53,'022013','ZUFARUL AKYAS','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(54,'022014','AFRAH AULA MAGHFIROH','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Magang','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:17:30'),
(55,'022015','ANGGI SHAFA FEBRIANDA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Magang','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:17:45'),
(56,'022016','AUFFA BILQIS SIDQIA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:18:49'),
(57,'022017','AYYASY NUWAYYIF','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(58,'022018','DEFENSE IRGI HARYONO','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(59,'022019','DIO ALIF PERMANA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(60,'022020','FADHAL ARYAN JAGADDITHA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(61,'022021','FAIRUUZ ZAHRAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(62,'022022','HAURANISA RIDHO ATHAYA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:08:42'),
(63,'022023','IRSYAD YARDAN NASYWA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(64,'022024','MUFIDAH ZAHRATUNNISA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:08:42'),
(65,'022025','MUHAMMAD AL KAHFI ZIKRI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(66,'022026','MUHAMMAD DIEN SYAFIQ','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(67,'022027','MUHAMMAD DZULFIKAR ABDUL AZIS','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(68,'022028','MUHAMMAD FARID HUSAIN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(69,'022029','MUHAMMAD NABIL NAJIB','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(70,'022030','MUHAMMAD NIZARUL AZKA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(71,'022031','MUHAMMAD TSAQIF ALFARISI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(72,'022032','MUHAMMAD XENA REVANDA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 07:16:43'),
(73,'022033','MUHAMMMAD ZAKI ATTORIQ','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(74,'022034','QUEEN MALIKA ANZANI','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:08:42'),
(75,'022035','RAYHAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(76,'022036','SHOFIYAH BADRES','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:08:42'),
(77,'022037','SYUKRINA BADRES','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:08:42'),
(78,'022038','TSAQIF MUWAFFAQ','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(79,'022039','YUSUF RAMADHANI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(80,'022040','ZIDAN ALBANI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(81,'022041','BAJA MALIK SYAHID','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','SIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(82,'022042','LEXY EVANDRA PUTRA ANGGARA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','SIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(83,'022043','MUHAMMAD LUTHFI AZIZ','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','SIT',22,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(84,'022044','NABILA MUNAWAROH','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','SIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(85,'022045','TSABITA ARINAL HAQ','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','SIT',22,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(86,'023001','ABDUL HANIF','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(87,'023002','ACHMAD NURUL HUDA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(88,'023003','AHMAD FATAH','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(89,'023004','ARMAN SYA\'BANI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 07:18:53'),
(90,'023005','AUFA ABABIL','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(91,'023006','AWTA DUDELA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Magang','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:18:13'),
(92,'023007','DAFFA ADITIYA MAZDA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(93,'023008','DIANDRA ABYAN ZAHRAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(94,'023009','FAAZA FADLAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(95,'023010','FADHLI AL FAJRI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(96,'023011','FAHRI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(97,'023012','FARUQ','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(98,'023013','FIRMANSYAH','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(99,'023014','HAFIZ HUDA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(100,'023015','IKHYA HASNUANSYAH','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 07:28:34'),
(101,'023016','ILHAN ROSHAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 07:23:43'),
(102,'023017','LUQMAN MALIKI L','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(103,'023018','MISBAHUN ALFIANTO','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(104,'023019','MUHAMMAD AKBAR ANNURSI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(105,'023020','MUHAMMAD AZZIZURRAHMAN IKRAM','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(106,'023021','MUHAMMAD FHAREL INTI PUTRA RACER','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(107,'023022','MUHAMMAD NAUFAL RAASYID','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(108,'023023','MUHAMMAD RAYHAN SAPUTRA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(109,'023024','MUHAMMAD SHOLEH','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(110,'023025','MUHAMMAD UKASYAH','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(111,'023026','RAIHAN NUR ICHSAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(112,'023027','YUSRIL YUDISTIRA','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(113,'023028','ZHAFRAN HARITS','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Lulus - Alumni','RIT',23,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:29:58'),
(114,'001001','IZWAN EFENDI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',1,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:21:00'),
(115,'001002','JUJUN SETIAWAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',1,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:21:00'),
(116,'001003','KHANIF ROZIQIN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',1,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:21:00'),
(117,'001004','MUHAMMAD AMIN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',1,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:21:00'),
(118,'001005','MUHAMMAD HAFIF AL BUSYRO','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',1,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:21:00'),
(119,'001006','SEPTIAWAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',1,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:21:00'),
(120,'001007','TRIYONO','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',1,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:21:00'),
(121,'001008','ZAKIYAH MUTHIATURRAHMAN','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',1,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:21:00'),
(122,'016002','AHMAD FAQIH','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',16,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:02:20'),
(123,'016003','AMRUL ZAMAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Tidak Aktif - diluar pondok','PIT',16,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:02:42'),
(124,'016004','DIMAZ AL-FATIHAH HILMI','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Tidak Aktif - diluar pondok','PIT',16,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:23:46'),
(125,'016005','MARCO ALEXANDER','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Tidak Aktif - diluar pondok','PIT',16,NULL,'PROGRAMMER',NULL,'2026-02-25 23:35:48','2026-02-26 01:23:46'),
(126,'016006','NURWAIDA JAMAL','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',16,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:24:33'),
(127,'016007','PUTRI CAHYA MAULIDA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Tidak Aktif - diluar pondok','PIT',16,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:23:46'),
(128,'016008','YOLLARIA SALMA SAFANA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',16,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:24:50'),
(129,'016009','ZAIMATUL KHAKIMAH','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alumni Aktif - dipondok','PIT',16,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-26 01:25:06'),
(130,'017003','ABDUL KHOLIQ','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',17,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(131,'017004','BINTANG','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',17,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(132,'017005','HUDZAIFAH','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',17,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(133,'017006','IQBAL','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',17,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(134,'017007','MADHAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',17,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(135,'017008','NISRINA NAFISA W','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',17,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(136,'017009','PARHAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',17,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(137,'017010','PURNA FITA WIDIA TANTRI','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',17,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(138,'018003','HASAN','L',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',18,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(139,'018004','RIZQIYA ENDAH OEMARGHANI','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',18,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(140,'019006','RAHMA AULIA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',19,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48'),
(141,'019007','RAJWA','P',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Santri Aktif','PIT',19,NULL,'BISNIS DIGITAL',NULL,'2026-02-25 23:35:48','2026-02-25 23:35:48');
/*!40000 ALTER TABLE `santris` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('4yHX9rg0sG9AtCSAADyBHgoEJkmy0nJbzePFEg4S',2,'162.158.108.71','Mozilla/5.0 (Android 16; Mobile; rv:147.0) Gecko/147.0 Firefox/147.0','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiYXBjUWdpQnhZVFdBcDRnVEViUjNhc3M0MTBSQzJGNE45aFBRREh4TSI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjMxOiJodHRwczovL3J1bWFoaXRodWIuY29tL3MvMDE2MDAxIjtzOjU6InJvdXRlIjtzOjIxOiJwdWJsaWMuc2FudHJpLnByb2ZpbGUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToyO30=',1772098916),
('BO9HAoAxx8loK1hbX5y43xeThfixEJHQMKa7S5rj',NULL,'172.71.122.198','Mozilla/5.0 (compatible; IbouBot/1.0; +bot@ibou.io; +https://ibou.io/iboubot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVDNsdTJFSVQ2VTJhTEI3UTdUdmdGUFo0Q0hmR09YblNsaWRSZmhFTyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vcnVtYWhpdGh1Yi5jb20iO3M6NToicm91dGUiO3M6Mjc6ImdlbmVyYXRlZDo6dVRJY2NQbVc1T3BCTGp1bCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1772099137),
('FJ3Rzsc31Ag5htbmKbVFFT1YUljFIjmvs7wAOLa2',NULL,'172.68.164.162','curl/8.5.0','YToyOntzOjY6Il90b2tlbiI7czo0MDoicnBCZkUyTlhkQUEwY0o3akdXbkdWOXVGN0FseG5ySWNIcmo0RmZtZyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1772096705),
('juqqLEDNVtw4bWtFtlNpH99NOAqWO5cI4XjLBsN0',NULL,'172.70.92.181','curl/8.12.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoicUFMTzRDU3NzeXNRd2laVWhSVjg2MXZsYWRBaUMxUnpkcmVLaGprMiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMjoiaHR0cHM6Ly9ydW1haGl0aHViLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1772093195),
('OqCwl9nZ3SavTcdGPLHgu3g5D2SgOU2mlmzLiiLX',NULL,'104.23.170.4','Mozilla/5.0 (Linux; U; Android 9; en-US; ASUS_X00TD Build/PKQ1) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.108 UCBrowser/12.12.8.1206 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSFpLWUNkRFdVSmlYNGJrN3N6T2gwRlBmWUlYWldoa3AzWEV0c1MxZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vd3d3LnJ1bWFoaXRodWIuY29tIjtzOjU6InJvdXRlIjtzOjI3OiJnZW5lcmF0ZWQ6OmJXY0V6MEgwNDNybDZ1a3EiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1772094706),
('QC0uszNwQs1sfOwLGy4bacT6AxUdf32Lc3YcHyl3',NULL,'172.71.102.216','Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiR203Ym1aM0x5cXpkVDdVUDN5cXp5VGNuSXJmRTJlV2lkN2oyQnR1RSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vcnVtYWhpdGh1Yi5jb20iO3M6NToicm91dGUiO3M6Mjc6ImdlbmVyYXRlZDo6dVRJY2NQbVc1T3BCTGp1bCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1772099442),
('SSPQTbGRc7KTXcZoWCXTfRVNkMf7HUMf9f8M4O4m',NULL,'104.23.168.46','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4240.193 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaWI1cWhPclM0em9qWDNSY0Rjd3V1b3RMQXQ2MFB0SE53MUwzSGRnNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vcnVtYWhpdGh1Yi5jb20iO3M6NToicm91dGUiO3M6Mjc6ImdlbmVyYXRlZDo6dVRJY2NQbVc1T3BCTGp1bCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1772098862),
('vnENh8zeyh5WV2Y6oMOlFR2LSH6bvUV6waWnjLBY',2,'172.70.92.180','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiYU5kUURWY2ZKQVpwODA1YXVzR1l3Y2hEWDdCTldqdGJLSk94a0lXVyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozMToiaHR0cHM6Ly9ydW1haGl0aHViLmNvbS9zLzAxNjAwMSI7czo1OiJyb3V0ZSI7czoyMToicHVibGljLnNhbnRyaS5wcm9maWxlIjt9fQ==',1772099610),
('XDs8vKPe8l0HMDg3i92JTTiqJ2ZR4yunZwTq3m3P',NULL,'172.70.92.181','curl/8.12.1','YToyOntzOjY6Il90b2tlbiI7czo0MDoiQ3gwU0tmTGlOU05aSEp5REp4UTBDcDR1Q05vWG10cEdUZUtNVFl3WCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1772092978),
('YctSSyhFJHMZPrmZXmAZf89Va3Rbz2ECYvu0PHHP',NULL,'162.158.108.71','curl/8.12.1','YToyOntzOjY6Il90b2tlbiI7czo0MDoiRmVtU2V2TldCbFRRT3R1NDd2VVpGSTY4UGxGUWM4aEx5SWVHeEZPZCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1772093065),
('YJ8Hc5fTMgiB70ErRj7hibwdB4eFtN0Z5VfaH3EZ',NULL,'162.158.88.58','curl/8.12.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaDlMZ0JhQTdvNHJiOW9TYnBJODNyS1NYSDNvWVhyeVRsWEFLQ2w1QiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMjoiaHR0cHM6Ly9ydW1haGl0aHViLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1772093196);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagihan_spps`
--

DROP TABLE IF EXISTS `tagihan_spps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tagihan_spps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `santri_id` bigint(20) unsigned NOT NULL,
  `bulan` varchar(255) DEFAULT NULL,
  `tahun` int(11) DEFAULT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `jatuh_tempo` date NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `status` enum('lunas','belum_lunas') NOT NULL DEFAULT 'belum_lunas',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `jenis_pembayaran_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tagihan_spps_santri_id_foreign` (`santri_id`),
  KEY `tagihan_spps_jenis_pembayaran_id_foreign` (`jenis_pembayaran_id`),
  CONSTRAINT `tagihan_spps_jenis_pembayaran_id_foreign` FOREIGN KEY (`jenis_pembayaran_id`) REFERENCES `jenis_pembayarans` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tagihan_spps_santri_id_foreign` FOREIGN KEY (`santri_id`) REFERENCES `santris` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagihan_spps`
--

LOCK TABLES `tagihan_spps` WRITE;
/*!40000 ALTER TABLE `tagihan_spps` DISABLE KEYS */;
INSERT INTO `tagihan_spps` VALUES
(1,56,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:46:14','2026-02-26 01:46:14',3),
(2,58,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:46:14','2026-02-26 01:46:14',3),
(3,78,'Februari',2026,2000000.00,'2026-02-10',NULL,'lunas','2026-02-26 01:46:14','2026-02-26 01:48:27',3),
(4,79,'Februari',2026,2000000.00,'2026-02-10',NULL,'lunas','2026-02-26 01:46:14','2026-02-26 01:53:52',3),
(5,86,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:46:14','2026-02-26 01:46:14',3),
(6,87,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:46:14','2026-02-26 01:46:14',3),
(7,96,'Februari',2026,2000000.00,'2026-02-10',NULL,'lunas','2026-02-26 01:46:14','2026-02-26 01:50:22',3),
(8,97,'Februari',2026,2000000.00,'2026-02-10',NULL,'lunas','2026-02-26 01:46:14','2026-02-26 01:53:21',3),
(9,98,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:46:14','2026-02-26 01:46:14',3),
(10,103,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:46:14','2026-02-26 01:46:14',3),
(11,108,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:46:14','2026-02-26 01:46:14',3),
(12,110,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:46:14','2026-02-26 01:46:14',3),
(13,112,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:46:14','2026-02-26 01:46:14',3),
(14,81,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:49:25','2026-02-26 01:49:25',3),
(15,82,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:49:25','2026-02-26 01:49:25',3),
(16,83,'Februari',2026,2000000.00,'2026-02-10',NULL,'lunas','2026-02-26 01:49:25','2026-02-26 01:49:45',3),
(17,84,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:49:25','2026-02-26 01:49:25',3),
(18,85,'Februari',2026,2000000.00,'2026-02-10',NULL,'belum_lunas','2026-02-26 01:49:25','2026-02-26 01:49:25',3),
(19,103,'Maret',2026,500000.00,'2026-03-10',NULL,'lunas','2026-02-26 07:15:41','2026-02-26 07:15:53',3),
(20,72,'Februari',2026,2000000.00,'2026-02-10',NULL,'lunas','2026-02-26 07:17:27','2026-02-26 07:17:38',3),
(21,89,'Februari',2026,2000000.00,'2026-02-10',NULL,'lunas','2026-02-26 07:19:41','2026-02-26 07:19:53',3),
(22,89,'Januari',2026,2000000.00,'2026-01-10',NULL,'lunas','2026-02-26 07:20:24','2026-02-26 07:20:33',3),
(23,101,'Januari',2026,2000000.00,'2026-01-10',NULL,'lunas','2026-02-26 07:21:50','2026-02-26 07:21:59',3),
(24,101,'Februari',2026,2000000.00,'2026-02-10',NULL,'lunas','2026-02-26 07:22:23','2026-02-26 07:22:30',3),
(25,83,NULL,NULL,1000000.00,'2026-02-26',NULL,'lunas','2026-02-26 07:25:03','2026-02-26 07:25:20',2),
(26,100,'Februari',2026,2000000.00,'2026-02-10',NULL,'lunas','2026-02-26 07:29:13','2026-02-26 07:29:22',3);
/*!40000 ALTER TABLE `tagihan_spps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Admin','admin@rumahithub.com',NULL,'$2y$12$aT5mCqBxt.n0r7NkVOfZlu9pB.POrn20n/sN64B.C7hMvFZZ.t7d6',NULL,'2026-02-25 22:14:13','2026-02-25 22:14:13'),
(2,'Triyono','admin@gmail.com',NULL,'$2y$12$JFaXifLr/JtnaNsy06tZeOCGVJjMOZDmehnKNkjApLQKZJcZL6Dw.',NULL,'2026-02-25 22:18:28','2026-02-25 22:18:28'),
(3,'admin-hrd','hrd@rumahithub.com',NULL,'$2y$12$D4VmaOTPd1iLoVK628rd4uXNUc4XKZhp8c0AuzY6SfkVXtdYsJ4zq',NULL,'2026-02-26 08:32:06','2026-02-26 08:32:06');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wali_santris`
--

DROP TABLE IF EXISTS `wali_santris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wali_santris` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `hubungan` varchar(255) NOT NULL,
  `no_hp` varchar(255) NOT NULL,
  `alamat` text DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `pekerjaan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wali_santris`
--

LOCK TABLES `wali_santris` WRITE;
/*!40000 ALTER TABLE `wali_santris` DISABLE KEYS */;
/*!40000 ALTER TABLE `wali_santris` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-26  9:55:47
